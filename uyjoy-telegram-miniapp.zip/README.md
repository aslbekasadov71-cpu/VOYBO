# UyJoy Telegram Mini App

Bu loyiha yuborgan shablon rasmlaringizdagi asosiy UX oqimini bitta ishlaydigan Telegram Mini App demo sifatida beradi:

- Bosh sahifa / e'lonlar
- Sotuv / ijara / kunlik / xaridor filtrlari
- Qidiruv
- Narx / xona / hudud bo'yicha filter
- E'lon detail oynasi
- Saqlangan e'lonlar
- Sotuvchilar katalogi
- E'lon joylash
- Profil
- Xarita (Leaflet + OpenStreetMap)
- Telegram WebApp integratsiyasi
- localStorage orqali demo ma'lumotlarni saqlash

## Ishga tushirish

Oddiy static hosting yetadi. `index.html` ni GitHub Pages, Render Static Site yoki boshqa hostingga joylash mumkin.

Telegram botga ulash uchun BotFather orqali Web App URL sifatida deploy qilingan URL'ni berasiz.

## Muhim

Hozirgi versiya backend/API siz demo holatda ishlaydi. Real foydalanuvchilar, real e'lonlar, rasmlarni serverga yuklash, moderatorlik, Telegram orqali xabar yuborish va autentifikatsiya uchun backend qo'shiladi.

Render uchun:
- Build command: bo'sh
- Publish directory: `.`
